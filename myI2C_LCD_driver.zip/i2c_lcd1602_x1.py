'''
    Filename: Two_I2C_1602_LCDs.py
    
    Demo of Two I2C_1602_LCDs Display on One NodeMCU (ESP8266) Board
    
    Mucker: Wm. Moore   (2019.6)
    
    Author: shaoziyang  (2018.2)
    
    http://www.micropython.org.cn   
    
'''

# This program requires the "i2c_lcd1602_V2.py" version
# of the original "lcd1602.py" driver which I modified so 
# the user could have 2 (or more?) I2C_1602_LCDs attached 
# to the same MCU board. Since these LCDs are commonly
# available with 2 different I2C addresses (0x27 and 0x3f),
# I used these two addresses rather than trying to figure
# out how to come up with other alternate I2C addresses by
# using the 3 jumper points on the I2C "back-pack" board
# labeled 'A0', 'A1' and 'A2'. So, theoretically, you could
# have a bunch of I2C_1602_LCD displays controlled by a
# single MCU board.
#
# On the ESP32, there are two set of pins designated for
# use with I2C bus compatible devices:
#
#     I2C Port 1:
#         GPIO pin 21 = SDA
#         GPIO pin 22 = SCL
#
#     I2C Port 2:
#         GPIO pin 12 = SDA
#         GPIO pin 14 = SCL
#
# I have tested both I2C ports and they work with this version 
# of my "lcd1602_Demo2.py" demo program.
#

from machine import I2C, Pin
from i2c_lcd1602a import *
import time

# Typically, the on-board blue LED for both ESP8266 & ESP32 is on the GPIO-2 pin.
led = Pin(2, Pin.OUT)

# I2C Port 1:
scl = Pin(22, Pin.OUT)    # ESP32's SCL is on GPIO pin 22 (on ESP8266 its on GPIO-4)
sda = Pin(21, Pin.OUT)    # ESP32's SDA is on GPIO pin 21 (on ESP8266 its on GPIO-5)

# I2C Port 2:
# scl = Pin(14, Pin.OUT)    # ESP32's SCL is on GPIO pin 14 (on ESP8266 its on GPIO-4)
# sda = Pin(12, Pin.OUT)    # ESP32's SDA is on GPIO pin 12 (on ESP8266 its on GPIO-5)

# XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
# XXXXXXX Declare 2 I2C class objects XXXXXXX
# XXXXXXX and 2 LCD1602 class objects XXXXXXX
# XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

# I2C Port 1 is used here for first & second I2C_1602_LCDs
myI2C1 = I2C(-1, scl, sda, freq=4000)  
myLcd1 = LCD1602(myI2C1, 0x27)
# myLcd2 = LCD1602(myI2C1, 0x3f)

# XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
# XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
# XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

# Define a could "test" strings to display
myString1 = "Hello, World!   "
myString2 = "0123456789ABCDEF"

while True:

    # Test the first I2C_LCD_1602 display (0x27) 
    myLcd1.puts("Hello, World!", 0, 0)

    # Send text to both LCD displays
    for i in range(0,16):
        myLcd1.puts(myString2[i], i, 1)      
        time.sleep(.5)
    time.sleep(3)

    # Test both I2C_1602_LCD Displays...
    # Longer Message Test:   (best to keep each message to 16 chars or less)
    myLcd1.clear()
    
    # Display & scroll two differnt long message strings
    myString3 = "A little knowledge is a dangerous thing."     # a 40 char string
    myLcd1.puts(myString3, 0, 0)
    
    # Max limit = string length - 16  (i.e. 40 - 16 = 24) 
    for i in range(0,24):
        myLcd1.shl()
        time.sleep(.5)
    time.sleep(3)
    
    # Clear both displays & repeat
    myLcd1.clear()
    time.sleep(1)

# EOF
