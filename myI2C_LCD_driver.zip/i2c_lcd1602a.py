'''

    i2c_lcd1602a.py
    
    Multiple I2C_1602_LCDs Driver
    
    ESP8266 driver for a I2C_1602_LCD
    
    Mucker: Wm Moore    (2019.6)  [This Works!]
    
    Author: shaoziyang  (2018.2)
    
    http://www.micropython.org.cn 

'''

import time
from machine import I2C

# Change #1: Comment-out this constant declaration
# LCD_I2C_ADDR=const(39)    # LCD_I2C_ADDR is usually 0x27 (39) or 0x3F (63).

class LCD1602():
    def __init__(self, i2c, addrs):    # Change #2: Added 3rd argument, a user supplied I2C address.
        self.i2c=i2c
        self.i2cAddrs=addrs            # Change #3: Added a variable to LCD1602 class to hold I2C Address.
        self.buf = bytearray(1)
        self.BK = 0x08
        self.RS = 0x00
        self.E = 0x04
        self.setcmd(0x33)
        time.sleep_ms(5)
        self.send(0x30)
        time.sleep_ms(5)
        self.send(0x20)
        time.sleep_ms(5)
        self.setcmd(0x28)
        self.setcmd(0x0C)
        self.setcmd(0x06)
        self.setcmd(0x01)
        self.version='1.0'

    def setReg(self, dat):
        self.buf[0] = dat
        self.i2c.writeto(self.i2cAddrs, self.buf)    # Change #4: Change 1st argument from constant to i2CAddrs variable.
        time.sleep_ms(1)

    def send(self, dat):
        d=dat&0xF0
        d|=self.BK
        d|=self.RS
        self.setReg(d)
        self.setReg(d|0x04)
        self.setReg(d)

    def setcmd(self, cmd):
        self.RS=0
        self.send(cmd)
        self.send(cmd<<4)

    def setdat(self, dat):
        self.RS=1
        self.send(dat)
        self.send(dat<<4)

    def clear(self):
        self.setcmd(1)

    def backlight(self, on):
        if on:
            self.BK=0x08
        else:
            self.BK=0
        self.setcmd(0)

    def on(self):
        self.setcmd(0x0C)

    def off(self):
        self.setcmd(0x08)

    def shl(self):
        self.setcmd(0x18)

    def shr(self):
        self.setcmd(0x1C)

    def char(self, ch, x=-1, y=0):
        if x>=0:
            a=0x80
            if y>0:
                a=0xC0
            a+=x
            self.setcmd(a)
        self.setdat(ch)

    def puts(self, s, x=0, y=0):
        if len(s)>0:
            self.char(ord(s[0]),x,y)
            for i in range(1, len(s)):
                self.char(ord(s[i]))

# EOF
