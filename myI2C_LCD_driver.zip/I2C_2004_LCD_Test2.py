'''
    Filename: I2C_2004_LCD_Test1.py
    
    This test program is designed to display 4 lines
    of text (20 characters per line) on a I2C_2004_LCD.
    This program requires my new "i2c_lcd.py" driver
    which supports either I2C_1602_LCDs or I2C_2004_LCDs.
    
    Mucker: Wm. Moore   (2019.6)
    
    Author: shaoziyang  (2018.2)    
    http://www.micropython.org.cn   
    
'''
# Feel free to remove comments to achieve better memory use.
#
# On the ESP8266, there is just one I2C port defined as:
#
#     I2C Port:
#         GPIO pin 4 = SDA
#         GPIO pin 5 = SCL
#
# To use the new "i2c_lcd.py" driver, upon instantiation of 
# LCD objects, you need to pass three arguments:
#
#     myLCD1 = LCD(myI2C, 0x27, 2004)
#
# Where "myI2C" is an instance of the I2C class from the "machine" library module, 
# "0x27" is the "I2C address" of the display module, and "2004" is the "model" of
# the display module. The I2C address is typically 0x3F (63) or 0x27 (39) while the
# model number is either "1602" or "2004". Here's another example:
#
#     myLCD2 = LCD(myI2C, 0x3F, 1602)
#

from machine import I2C, Pin
from time import sleep
from i2c_lcd import *

# The ESP8266 MCU has just one I2C port where
# the I2C "SCL" signal is on GPIO-4 and 
# the I2C "SDA" signal is on GPIO-5:
myI2C = I2C(scl=Pin(5), sda=Pin(4), freq=400000)

myLCD1 = LCD(myI2C, 0x27, 2004)    # For I2C_2004_LCD with I2C address of 0x27 (39)
# myLCD1 = LCD(myI2C, 0x3F, 1602)    # For I2C_1602_LCD with I2C address of 0x3F (63)

# Define a could "test" strings to display
myString1 = "Hello, World!"
myString2 = "0123456789ABCDEFwxyz"
myString3 = "abcdefghijklmnopqrst"   # uvwxyz"
myString4 = "ABCDEFGHIJKLMNOPQRST"   # UVWXYZ"

# Debug code:
print("==> " + str(myLCD1.model))

while True:

    # Send 1st line of text to 2004_LCD display
    myLCD1.puts(myString1, 0, 0)
    sleep(2)
    myLCD1.puts(myString2, 0, 1)
    sleep(2)
    myLCD1.puts(myString3, 0, 2)
    sleep(2)
    myLCD1.puts(myString4, 0, 3)
    sleep(5)
    
    # Clear LCD
    myLCD1.clear()
    sleep(1)

    # Send 1st line of text to 2004_LCD display (1 char/0.5 sec)
    for i in range(0, len(myString1)):
        myLCD1.puts(myString1[i], i, 0)
        sleep(.25)
    sleep(3)

    # Send 2nd line of text to 2004_LCD display (1 char/0.5 sec)
    for i in range(0,20):
        myLCD1.puts(myString2[i], i, 1)
        sleep(.25)
    sleep(3)

    # Send 3rd line of text to 2004_LCD display
    for i in range(0,20):
        myLCD1.puts(myString3[i], i, 2)
        sleep(.25)
    sleep(3)

    # Send 4th line of text to 2004_LCD display
    for i in range(0,20):
        myLCD1.puts(myString4[i], i, 3)
        sleep(.25)
    sleep(3)

    # Clear LCD
    myLCD1.clear()
    sleep(1)

    '''
    # This does not work as it did with a I2C_1602_LCD. I suspect that 
    # the 1602 LCD and the 2004 LCD have the same amount of buffer memory
    # which allowed this with a 2-line 1602LCD but not a 4-line 2004LCD.
    # Display & scroll a long message strings
    myString3 = "A little knowledge is a dangerous thing."     # a 40 char string
    myLCD1.puts(myString3, 0, 0)
      
    # Max limit = string length - 16  (i.e. 40 - 16 = 24) 
    for i in range(0,24):
        myLCD1.shl()
        sleep(.5)
    sleep(3)

    # Clear LCD
    myLCD1.clear()
    sleep(1)
    '''
    
# EOF
