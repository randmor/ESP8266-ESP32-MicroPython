'''
    Filename: i2c_lcd1602_x3.py
    
    Demo of Three I2C_1602_LCDs Displays on One NodeMCU-32S (ESP32) Board
 
    The first two LCDs are on I2C Port #1, while the third LCD is on
    I2C Port #2.
    
    Mucker: Wm Moore    (2019.6)
    
    Author: shaoziyang  (2018.2)
    
    http://www.micropython.org.cn   
    
'''
# To get a 3rd (and 4th) I2C_1602_LCD display to work on
# the same NodeMCU-32S (ESP-32) board, I thought I would
# try using the second I2C port on the ESP32. Whether
# this is a rreal I2C port supported by hardware on the
# ESP-32, or is a software I2C port, I don't know. But it
# was mentioned as such, so I'll give it a
#
#     I2C Port 2:
#         GPIO pin 12 = SDA
#         GPIO pin 14 = SCL
#
# This program requires the "i2c_lcd1602_V2.py" version
# of the original "lcd1602.py" driver which I modified so 
# the user could have 2 (or more?) I2C_1602_LCDs attached 
# to the same MCU board. Since these LCDs are commonly
# available with 2 different I2C addresses (0x27 and 0x3f),
# I used these two addresses rather than trying to figure
# out how to come up with other alternate I2C addresses by
# using the 3 jumper points on the I2C "back-pack" board
# labeled 'A0', 'A1' and 'A2'. So, theoretically, you could
# have a bunch of I2C_1602_LCD displays controlled by a
# single MCU board.
#
# On the ESP32, there are two set of pins designated for
# use with I2C bus compatible devices:
#
#     I2C Port 1:
#         GPIO pin 21 = SDA
#         GPIO pin 22 = SCL
#
#     I2C Port 2:
#         GPIO pin 12 = SDA
#         GPIO pin 14 = SCL
#
# I have tested both I2C ports and they work with this version 
# of my "lcd1602_Demo2.py" demo program.
#

from machine import I2C, Pin
from i2c_lcd1602_V2 import *
import time

# Typically, the on-board blue LED for both ESP8266 & ESP32 is on the GPIO-2 pin.
led = Pin(2, Pin.OUT)

scl1 = Pin(22, Pin.OUT)    # ESP32's SCL is on GPIO pin 22 (on ESP8266 its on GPIO-4)
sda1 = Pin(21, Pin.OUT)    # ESP32's SDA is on GPIO pin 21 (on ESP8266 its on GPIO-5)

scl2 = Pin(14, Pin.OUT)    # ESP32's SCL is on GPIO pin 14 (on ESP8266 its on GPIO-4)
sda2 = Pin(12, Pin.OUT)    # ESP32's SDA is on GPIO pin 12 (on ESP8266 its on GPIO-5)

# XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
# XXXXXXX Declare 2 I2C class objects XXXXXXX
# XXXXXXX and 2 LCD1602 class objects XXXXXXX
# XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

# I2C Port 1 used for first & second I2C_1602_LCDs
myI2C1 = I2C(-1, scl1, sda1, freq=4000)  
myLcd1 = LCD1602(myI2C1, 0x27)
myLcd2 = LCD1602(myI2C1, 0x3f)

# I2C Port 2 used for my third & fourth I2C_1602_LCDs
myI2C2 = I2C(-1, scl2, sda2, freq=4000)  
myLcd3 = LCD1602(myI2C2, 0x3f)
# myLcd4 = LCD1602(myI2C2, 0x27)

# XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
# XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
# XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

# Define a could "test" strings to display
myString1 = "Hello, World!   "
myString2 = "0123456789ABCDEF"

while True:

    # Test the first I2C_LCD_1602 display   (I2C Port1, Address 0x27) 
    myLcd1.puts("Hello, World!", 0, 0)
    
    # Test the second I2C_LCD_1602 display  (I2C Port1, Address 0x3F)
    myLcd2.puts("Hello, World!", 0, 0)
    
    # Test the third I2C_LCD_1602 display   (I2C Port2, Address 0x3F)
    myLcd3.puts("Hello, World!", 0, 0)
    
    # Send text to all 3 LCD displays
    for i in range(0,16):
        myLcd1.puts(myString2[i], i, 1)
        myLcd2.puts(myString2[i], i, 1)
        myLcd3.puts(myString2[i], i, 1)  
        time.sleep(.25)
    time.sleep(3)

    # Test both I2C_1602_LCD Displays...
    # Longer Message Test:   (best to keep each message to 16 chars or less)
    myLcd1.clear()
    myLcd2.clear()
    myLcd3.clear()

    # Display & scroll two differnt long message strings
    myString3 = "A little knowledge is a dangerous thing."     # a 40 char string
    myString4 = "You can't have your cake and eat it too."
    myString5 = "There's more than one way to skin a cat."
    
    myLcd1.puts(myString3, 0, 0)
    myLcd2.puts(myString4, 0, 0)
    myLcd3.puts(myString5, 0, 0)
    
    # Max limit = string length - 16  (i.e. 40 - 16 = 24) 
    for i in range(0,24):
        myLcd1.shl()
        myLcd2.shl()
        myLcd3.shl()
        time.sleep(.25)
    time.sleep(3)
    
    # Clear both displays & repeat
    myLcd1.clear()
    myLcd2.clear()
    myLcd3.clear()
    time.sleep(1)

# EOF
