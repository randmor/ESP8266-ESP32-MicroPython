'''
    Filename: Two_I2C_1602_LCDs.py
    
    Demo of Two I2C_1602_LCDs Display on One NodeMCU (ESP8266) Board
    
    Mucker: Wm. Moore   (2019.6)  [This Works!]
    
    Author: shaoziyang  (2018.2)
    
    http://www.micropython.org.cn   
    
'''

# This program requires the "i2c_lcd1602_a.py" version
# of the original "lcd1602.py" driver which I modified so 
# the user could have 2 (or more?) I2C_1602_LCDs attached 
# to the same MCU board. Since these LCDs are commonly
# available with 2 different I2C addresses (0x27 and 0x3f),
# I used these two addresses rather than trying to figure
# out how to come up with other alternate I2C addresses by
# using the 3 jumper points on the I2C "back-pack" board
# labeled 'A0', 'A1' and 'A2'. So, theoretically, you could
# have a bunch of I2C_1602_LCD displays controlled by a
# single MCU board.
#
# On the ESP8266, there is just one I2C port defined as:
#
#     I2C Port:
#         GPIO pin 4 = SDA
#         GPIO pin 5 = SCL
#

from machine import I2C, Pin
from time import sleep
from i2c_lcd1602a import *

# Typically, the on-board LED for the ESP8266 is on the GPIO-2 pin.
led = Pin(2, Pin.OUT)

# The ESP8266 MCU has just one I2C port where the I2C "SCL" signal is on GPIO-4
# and the I2C "SDA" signal is on GPIO-5.
myI2C = I2C(scl=Pin(5), sda=Pin(4), freq=400000)

myLCD1 = LCD1602(myI2C, 0x27)    # For I2C_1602_LCD with I2C address of 0x27 (39)
myLCD2 = LCD1602(myI2C, 0x3f)    # For I2C_1602_LCD with I2C address of 0x3F (63)

# Define a could "test" strings to display
myString1 = "Hello, World!   "
myString2 = "0123456789ABCDEF"

while True:

    # Test the first I2C_LCD_1602 display (0x27) 
    myLCD1.puts("Hello, World!", 0, 0)

    # Test the second I2C_LCD_1602 display (0x3F) 
    myLCD2.puts("Hello, World!", 0, 0)

    # Send text to both LCD displays
    for i in range(0,16):
        myLCD1.puts(myString2[i], i, 1)
        myLCD2.puts(myString2[i], i, 1)
        sleep(.5)
    sleep(3)

    # Clear both LCDs
    myLCD1.clear()
    myLCD2.clear()
    sleep(1)

    # Test both I2C_1602_LCD Displays with a longer message.
    # (Seems best to keep each message to 16 chars or less)
    #
    # Display & scroll two differnt long message strings
    myString3 = "A little knowledge is a dangerous thing."     # a 40 char string
    myLCD1.puts(myString3, 0, 0)
    
    myString4 = "You can't have your cake and eat it too."     # a 40 char string
    myLCD2.puts(myString4, 0, 0)    
    
    # Max limit = string length - 16  (i.e. 40 - 16 = 24) 
    for i in range(0,24):
        myLCD1.shl()
        myLCD2.shl()
        sleep(.5)
    time.sleep(3)
    
    # Clear both LCDs
    myLCD1.clear()
    myLCD2.clear()
    sleep(1)

# EOF
