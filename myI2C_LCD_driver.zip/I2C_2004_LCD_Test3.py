'''
    Filename: I2C_2004_LCD_Test3.py
    
    Testing with one I2C_2004_LCD and one I2C_1602_LCD. 
    
    This test program is designed to display 4 lines
    of text (20 characters per line) on a I2C_2004_LCD.
    This program requires my new "i2c_lcd.py" driver
    which supports either I2C_1602_LCDs or I2C_2004_LCDs.
    
    Mucker: Wm. Moore   (2019.6)
    
    Author: shaoziyang  (2018.2)    
    http://www.micropython.org.cn   
    
'''
# Feel free to remove comments to achieve better memory use.
#
# On the ESP8266, there is just one I2C port defined as:
#
#     I2C Port:
#         GPIO pin 4 = SDA
#         GPIO pin 5 = SCL
#
# To use the new "i2c_lcd.py" driver, upon instantiation of 
# LCD objects, you need to pass three arguments:
#
#     myLCD1 = LCD(myI2C, 0x27, 2004)
#
# Where "myI2C" is an instance of the I2C class from the "machine" library module, 
# "0x27" is the "I2C address" of the display module, and "2004" is the "model" of
# the display module. The I2C address is typically 0x3F (63) or 0x27 (39) while the
# model number is either "1602" or "2004". Here's another example:
#
#     myLCD2 = LCD(myI2C, 0x3F, 1602)
#

from machine import I2C, Pin
from time import sleep
from i2c_lcd import *

# The ESP8266 MCU has just one I2C port where
# the I2C "SCL" signal is on GPIO-4 and 
# the I2C "SDA" signal is on GPIO-5:
myI2C = I2C(scl=Pin(5), sda=Pin(4), freq=400000)

myLCD1 = LCD(myI2C, 0x27, 2004)    # For I2C_2004_LCD with I2C address of 0x27 (39)
myLCD2 = LCD(myI2C, 0x3F, 1602)    # For I2C_1602_LCD with I2C address of 0x3F (63)

# Define a could "test" strings to display
myString1 = "Hello, World!       "
myString2 = "0123456789ABCDEFwxyz"
myString3 = "abcdefghijklmnopqrst"   # uvwxyz"
myString4 = "ABCDEFGHIJKLMNOPQRST"   # UVWXYZ"

# Debug code:
print("==> " + str(myLCD1.model))

while True:

    # Send text to  both LCD displays (but in reverse order)
    myLCD1.puts(myString1, 0, 0)
    myLCD2.puts(myString4, 0, 0)
    sleep(2)
    myLCD1.puts(myString2, 0, 1)
    myLCD2.puts(myString3, 0, 1)    
    sleep(5)
    myLCD1.puts(myString3, 0, 2)
    myLCD2.puts(myString2, 0, 2)
    sleep(2)
    myLCD1.puts(myString4, 0, 3)
    myLCD2.puts(myString1, 0, 3)    
    sleep(5)
    
    # Clear LCD
    myLCD1.clear()
    myLCD2.clear()
    sleep(1)

    # Send 1st line of text to both displays (1 char/0.5 sec)
    for i in range(0, len(myString1)):
        myLCD1.puts(myString1[i], i, 0)
        myLCD2.puts(myString4[i], i, 1)
        sleep(.25)
    sleep(3)

    # Send 2nd line of text to both displays (1 char/0.5 sec)
    for i in range(0,20):
        myLCD1.puts(myString2[i], i, 1)
        myLCD2.puts(myString3[i], i, 0)
        sleep(.25)
    sleep(3)

    # Send 3rd line of text to both displays 
    for i in range(0,20):
        myLCD1.puts(myString3[i], i, 2)
        myLCD2.puts(myString2[i], i, 1)
        sleep(.25)
    sleep(3)

    # Send 4th line of text to both displays 
    for i in range(0,20):
        myLCD1.puts(myString4[i], i, 3)
        myLCD2.puts(myString1[i], i, 0)
        sleep(.25)
    sleep(3)

    # Clear LCD
    myLCD1.clear()
    myLCD2.clear()
    sleep(1)
 
# EOF
