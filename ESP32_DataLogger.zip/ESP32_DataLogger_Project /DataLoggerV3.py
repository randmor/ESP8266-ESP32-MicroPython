'''
    DataLoggerV3.py 

    See DataLoggerV2.py source code for detailed comments.

    By Wm. Moore, 7/7/2019.    Running program for hours...
  
    Seems like maybe we can go a day taking 4 readings an hour
    before we get memory allocation errors and the program
    crashes. I'm thinking maybe once a day, we create a new
    datafile and write to it instead of the previous one so
    this program can run for days, if not weeks, before the
    SD-Card has to be pulled so the data files can be collected
    and processed on a PC. A new micro-SD Card would then be put
    in the micro-SD-Card adapter and we could go that many days
    again... Maybe can make the date part of the filename.
    
    Ultimately, the data can be uploaded to the PC using WiFi,
    but I haven't got that far yet.
  
'''
from machine import I2C, SPI, Pin
from time import sleep
from i2c_lcd_v3 import *
import DS1302
import dht 
import sdcard
import os

def fileExists(filename):
    try:
        os.stat(filename)
        return True;
    except OSError:
        return False

myI2C = I2C(scl=Pin(22), sda=Pin(21), freq=400000)
myLcd = LCD(myI2C, 0x27, 2004)

myLcd.createChar(0, bytearray([0x06, 0x09, 0x09, 0x06, 0x00, 0x00, 0x00, 0x00]))  # Degrees symbol
sensor = dht.DHT11(Pin(15))

myRTC = DS1302.DS1302(clk=Pin(4), dio=Pin(16), cs=Pin(17))

# Set RTC with current date and time (Do One Time!)
# myRTC.DateTime([2019, 7, 7, 6, 8, 40, 0, 0])

vspi = SPI(2, sck=Pin(18), mosi=Pin(23), miso=Pin(19))
vspi.init()
sd = sdcard.SDCard(vspi, Pin(5))
vfs = os.VfsFat(sd)
if not fileExists('/dlog'):
    os.mount(vfs, '/dlog')

filename = "/dlog/dataLog1.txt"
prevData = ""

while True:
    myLcd.clear()
    yyyy = myRTC.Year()
    mm = myRTC.Month()
    if mm < 10:
        mm = "0" + str(mm)
    dd = myRTC.Day()
    if dd < 10:
        dd = "0" + str(dd)
    hh = myRTC.Hour()
    if hh < 10:
        hh = "0" + str(hh)
    mn = myRTC.Minute()
    if mn < 10:
        mn = "0" + str(mn)
    dateString = "Date: " + str(mm) + '/' + str(dd) + '/' + str(yyyy) 
    timeString = "Time: " + str(hh) + ':' + str(mn)
    myLcd.puts(dateString, 0, 0)
    myLcd.puts(timeString, 0, 1)       
    sensor.measure()
    temp = sensor.temperature()
    hum = sensor.humidity()
    temp_f = round(temp * (9/5) + 32.0, 1)
    tempString = "Temp: " + str(temp_f) + " " + str(chr(0x00)) + "F"
    humiString = "Humidity:  " + str(hum) + " %"
    myLcd.puts(tempString, 0, 2)
    myLcd.puts(humiString, 0, 3)
    newData = str(mm)+','+str(dd)+','+str(yyyy)+','+str(hh)+','+str(mn)+','+str(temp_f)+','+str(hum)+"\n"
    print(newData)
    if fileExists(filename):
        with open(filename,'r') as file1:
            prevData = file1.read()
        with open(filename,'w') as file1:
            n = file1.write(prevData + newData) 
    else:
        # print("Data file '" + filename + "' was not found. Creating new data file.")  # Debug code
        myLcd.clear()
        myLcd.puts("Data file not found.", 0, 0)
        myLcd.puts("Creating new file...", 0, 1)
        sleep(10)
        with open(filename,'w') as file1:
            n = file1.write("mm,dd,yyyy,hh,mn,temp,hum\n")
        continue
    
    sleep(900)  # Sample every 15 minutes
    
# EOF



