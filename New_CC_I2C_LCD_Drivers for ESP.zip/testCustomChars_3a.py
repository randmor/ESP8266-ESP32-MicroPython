'''
    In this version, I have un-embedded the LCD class
    definition and saved it as "i2c_lcd_v3.py". So,
    now you wull see a "from i2c_lcd_v2 import *"
    instruction in its place.

    I have developed a new version of "i2c_lcd" driver
    that supports custom characters. The LCD class now
    has a "create_char()" method that will allow the
    user to define and display custom characters.

    Below is a URL to a helpful online utility to help 
    you create custom characters for the 1602_LCD display
    (and other similar HD44780 compatible displays like
    the 2004_LCD). Be sure to select "Character size: 5x8"
    from the drop-down selection box. Here's that URL:
    
    https://www.quinapalus.com/hd44780udg.html
    
    Now adding support for ESP32...
    
    #
    # On the ESP8266, there is just one designate I2C port:
    #
    #     I2C Port:
    #         GPIO pin 4 = SDA
    #         GPIO pin 5 = SCL
    #
    # On the ESP32, there are two set of pins designated for
    # use with I2C bus compatible devices:
    #
    #     I2C Port 1:
    #         GPIO pin 21 = SDA
    #         GPIO pin 22 = SCL
    #
    #     I2C Port 2:
    #         GPIO pin 12 = SDA
    #         GPIO pin 14 = SCL
    #

    
    

'''

from time import sleep
from machine import Pin, I2C
from i2c_lcd_v3 import *

# Test Program for New Custom Character Code vesion of i2c_lcd_v3.py
# In this test, we'll create same 8 custom characters for both the 
# I2C_1602_LCD and the I2C_2004_LCD displays..

# ------ Pick an I2C Port ------
#
# Setup I2C Port on ESP8266:
# myI2C = I2C(scl=Pin(5), sda=Pin(4), freq=400000)
#
# Setup I2C Port on ESP32 I2C port #1:
myI2C = I2C(scl=Pin(22), sda=Pin(21), freq=400000)
#
# Setup I2C Port on ESP32 I2C port #2:
# myI2C = I2C(scl=Pin(14), sda=Pin(12), freq=400000)
#
# ------------------------------

# Setup one I2C_1602_LCD device:
myLCD1 = LCD(myI2C, 0x3F, 1602)    # For I2C_1602_LCD with I2C address of 0x3F (63)

# Setup one I2C_2004_LCD device:
myLCD2 = LCD(myI2C, 0x27, 2004)    # For I2C_2004_LCD with I2C address of 0x27 (39)


# =====================
# TEST #1: I2C_1602_LCD
# =====================

# Display program title on first line of LCD display
myLCD1.puts("CustChar Test #1", 0, 0)

# Create a byte array to define the lit pixels of each of the eight custom character
myLCD1.createChar(0, bytearray([0x06, 0x09, 0x09, 0x06, 0x00, 0x00, 0x00, 0x00]))  # Degrees symbol
myLCD1.createChar(1, bytearray([0x07, 0x08, 0x1E, 0x08, 0x1E, 0x08, 0x07, 0x00]))  # Euros symbol
myLCD1.createChar(2, bytearray([0x02, 0x03, 0x02, 0x0E, 0x1E, 0x0C, 0x00, 0x00]))  # Music note
myLCD1.createChar(3, bytearray([0x00, 0x00, 0x0A, 0x00, 0x11, 0x0E, 0x00, 0x00]))  # Happy Face
myLCD1.createChar(4, bytearray([0x00, 0x00, 0x0A, 0x00, 0x0E, 0x11, 0x00, 0x00]))  # Sad Face
myLCD1.createChar(5, bytearray([0x00, 0x0A, 0x1F, 0x1F, 0x0E, 0x04, 0x00, 0x00]))  # Heart
myLCD1.createChar(6, bytearray([0x00, 0x01, 0x03, 0x16, 0x1C, 0x08, 0x00, 0x00]))  # Check Mark
myLCD1.createChar(7, bytearray([0x00, 0x1B, 0x0E, 0x04, 0x0E, 0x1B, 0x00, 0x00]))  # X-mark

# Display all 8 custom characters on line 1 of LCD
myLCD1.puts(str(chr(0x00)), 0, 1)    # Degrees symbol
myLCD1.puts(str(chr(0x01)), 1, 1)    # Euros symbol
myLCD1.puts(str(chr(0x02)), 2, 1)    # Music note
myLCD1.puts(str(chr(0x03)), 3, 1)    # Happy Face
myLCD1.puts(str(chr(0x04)), 4, 1)    # Sad Face
myLCD1.puts(str(chr(0x05)), 5, 1)    # Heart
myLCD1.puts(str(chr(0x06)), 6, 1)    # Check Mark
myLCD1.puts(str(chr(0x07)), 7, 1)    # X-mark
sleep(2)

# A more real world example:
degC = 22.0
myLCD1.puts(str(degC) + str(chr(0x00)) + "C" + str(chr(0x03)), 9, 1)
sleep(2)


# =====================
# TEST #2: I2C_2004_LCD
# =====================

# Display program title on first line of LCD display
myLCD2.puts("CustChar Test #2", 0, 0)

sleep(2)

# Create a byte array to define the lit pixels of each of the eight custom character
myLCD2.createChar(0, bytearray([0x06, 0x09, 0x09, 0x06, 0x00, 0x00, 0x00, 0x00]))  # Degrees symbol
myLCD2.createChar(1, bytearray([0x07, 0x08, 0x1E, 0x08, 0x1E, 0x08, 0x07, 0x00]))  # Euros symbol
myLCD2.createChar(2, bytearray([0x02, 0x03, 0x02, 0x0E, 0x1E, 0x0C, 0x00, 0x00]))  # Music note
myLCD2.createChar(3, bytearray([0x00, 0x00, 0x0A, 0x00, 0x11, 0x0E, 0x00, 0x00]))  # Happy Face
myLCD2.createChar(4, bytearray([0x00, 0x00, 0x0A, 0x00, 0x0E, 0x11, 0x00, 0x00]))  # Sad Face
myLCD2.createChar(5, bytearray([0x00, 0x0A, 0x1F, 0x1F, 0x0E, 0x04, 0x00, 0x00]))  # Heart
myLCD2.createChar(6, bytearray([0x00, 0x01, 0x03, 0x16, 0x1C, 0x08, 0x00, 0x00]))  # Check Mark
myLCD2.createChar(7, bytearray([0x00, 0x1B, 0x0E, 0x04, 0x0E, 0x1B, 0x00, 0x00]))  # X-mark

# Display all 8 custom characters on line 0 of LCD
myLCD2.puts(str(chr(0x00)), 0, 0)    # Degrees symbol
myLCD2.puts(str(chr(0x01)), 1, 0)    # Euros symbol
myLCD2.puts(str(chr(0x02)), 2, 0)    # Music note
myLCD2.puts(str(chr(0x03)), 3, 0)    # Happy Face
myLCD2.puts(str(chr(0x04)), 4, 0)    # Sad Face
myLCD2.puts(str(chr(0x05)), 5, 0)    # Heart
myLCD2.puts(str(chr(0x06)), 6, 0)    # Check Mark
myLCD2.puts(str(chr(0x07)), 7, 0)    # X-mark
sleep(2)

# Display all 8 custom characters on line 1 of LCD
myLCD2.puts(str(chr(0x00)), 0, 1)
myLCD2.puts(str(chr(0x01)), 1, 1)
myLCD2.puts(str(chr(0x02)), 2, 1)
myLCD2.puts(str(chr(0x03)), 3, 1)
myLCD2.puts(str(chr(0x04)), 4, 1)
myLCD2.puts(str(chr(0x05)), 5, 1)
myLCD2.puts(str(chr(0x06)), 6, 1)
myLCD2.puts(str(chr(0x07)), 7, 1)
sleep(2)

# Display all 8 custom characters on line 2 of LCD
myLCD2.puts(str(chr(0x00)), 0, 2)
myLCD2.puts(str(chr(0x01)), 1, 2)
myLCD2.puts(str(chr(0x02)), 2, 2) 
myLCD2.puts(str(chr(0x03)), 3, 2)
myLCD2.puts(str(chr(0x04)), 4, 2)
myLCD2.puts(str(chr(0x05)), 5, 2)
myLCD2.puts(str(chr(0x06)), 6, 2)
myLCD2.puts(str(chr(0x07)), 7, 2)
sleep(2)

# Display all 8 custom characters on line 3 of LCD
myLCD2.puts(str(chr(0x00)), 0, 3)
myLCD2.puts(str(chr(0x01)), 1, 3)
myLCD2.puts(str(chr(0x02)), 2, 3)
myLCD2.puts(str(chr(0x03)), 3, 3)
myLCD2.puts(str(chr(0x04)), 4, 3)
myLCD2.puts(str(chr(0x05)), 5, 3)
myLCD2.puts(str(chr(0x06)), 6, 3)
myLCD2.puts(str(chr(0x07)), 7, 3)
sleep(2)

# A more real world example:
degC = 22.0
myLCD2.puts(str(degC) + str(chr(0x00)) + "C ", 9, 0)
sleep(2)
myLCD2.puts(str(degC) + str(chr(0x00)) + "C ", 9, 1)
sleep(2)
myLCD2.puts(str(degC) + str(chr(0x00)) + "C ", 9, 2)
sleep(2)
myLCD2.puts(str(degC) + str(chr(0x00)) + "C ", 9, 3)
sleep(2)

# Display more custom characters as the last 4 characters of each line on 2004 display
myLCD2.puts(str(chr(0x03)) + str(chr(0x04)) + str(chr(0x05)) + str(chr(0x06)), 16, 0)
sleep(2)
myLCD2.puts(str(chr(0x03)) + str(chr(0x04)) + str(chr(0x05)) + str(chr(0x06)), 16, 1)
sleep(2)
myLCD2.puts(str(chr(0x03)) + str(chr(0x04)) + str(chr(0x05)) + str(chr(0x06)), 16, 2)
sleep(2)
myLCD2.puts(str(chr(0x03)) + str(chr(0x04)) + str(chr(0x05)) + str(chr(0x06)), 16, 3)
sleep(2)

# EOF


