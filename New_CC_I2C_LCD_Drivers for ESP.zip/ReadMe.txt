
Testing Notes:

The latest I2C_1602/2004_LCD library with this new custom character support is called "i2c_lcd_v3.py".
It has been tested with both ESP8266 and ESP32 MCU boards. Specifically, the NodeMCU (ESP8266) and 
the ModeMCU-32S (ESP-32) boards from Ai-Thinker. I also did some testing on the "Feather HUZZAH 
ESP8266" board from Adafruit. I have 3 test programs to test various configurations:

1.) My test program "testCustomChars_3a.py" was written for ESP8266 with one I2C_1602_LCD (0x3F)
    and one I2C_2004_LCD (0x27) both using the same I2C port (SDA = GPIO4, SCL = GPIO5)

2.) My test program "testCustomChars_3b.py" was modified for ESP32 with one I2C_1602_LCD (0x3F)
    and one I2C_2004_LCD (0x27) both using the same I2C port (Port #1: SDA = GPIO21, SCL = GPI22)

3.) My test program "testCustomChars_3c.py" was  modified for ESP32 with two I2C_1602_LCDs (both 0x3F)
    and two I2C_2004_LCDs (both 0x27). To make this work, I set up two I2C objects, each with one 
    I2C_1602_LCD and one I2C_2004_LCD. Since the matching I2C addresses are now on different I2C 
    buses, they are unique enough for the software to differentiate. The second I2C port uses GPIO12
    for SDA and GPIO14 for SCL.

Because each LCD display has its own CGRAM (memory where the pixel data for the 8 custom characters) 
go, I had to use the createChar() method a bunch of times (32 times), to set up the same set of 
custom characters for each of the 4 displays. I copied and pasted this code 4 times rather than 
write some more generalized (and cryptic) code that would save memory by only having one copy of 
the custom character pixel data in memory data time. This is a quick & dirty test program, after all.

Test results: Everything works as expected.


# -----------------------------------------------------------------------------------------------------

My "V3" version of the "i2c_lcd" library module now supports custom characters. I have added 
a new method called "createChar()" to the LCD class that allows the user/programmer to define 
up to eight custom characters (all that the 1602LCD supports) and then program that data into 
the LCD display. In the test program I wrote to test this latest version of "i2clcd_v3", I 
defined the 8 custom characters using a byte array as follows:

    # Create a byte array to define the lit pixels of each of the eight custom character
    myLCD1.createChar(0, bytearray([0x06, 0x09, 0x09, 0x06, 0x00, 0x00, 0x00, 0x00]))  # Degrees symbol
    myLCD1.createChar(1, bytearray([0x07, 0x08, 0x1E, 0x08, 0x1E, 0x08, 0x07, 0x00]))  # Euros symbol
    myLCD1.createChar(2, bytearray([0x02, 0x03, 0x02, 0x0E, 0x1E, 0x0C, 0x00, 0x00]))  # Music note
    myLCD1.createChar(3, bytearray([0x00, 0x00, 0x0A, 0x00, 0x11, 0x0E, 0x00, 0x00]))  # Happy Face
    myLCD1.createChar(4, bytearray([0x00, 0x00, 0x0A, 0x00, 0x0E, 0x11, 0x00, 0x00]))  # Sad Face
    myLCD1.createChar(5, bytearray([0x00, 0x0A, 0x1F, 0x1F, 0x0E, 0x04, 0x00, 0x00]))  # Heart
    myLCD1.createChar(6, bytearray([0x00, 0x01, 0x03, 0x16, 0x1C, 0x08, 0x00, 0x00]))  # Check Mark
    myLCD1.createChar(7, bytearray([0x00, 0x1B, 0x0E, 0x04, 0x0E, 0x1B, 0x00, 0x00]))  # X-mark

There is a webpage called "HD44780 LCD User-Defined Graphics" (see URL below) with some very useful 
tools that I used to generate the hexidecimal data that definess these custom characters. Be sure to 
select the "Character size 5 by 8" option as the program defaults to "Character size 5 by 7", and we 
need 5x8. A 5x8 matrix is then provided which you can click on and the pixel at the given location 
will be made to light up. They also have a pattern library to select custom characters from. It's a 
good place to start. Here's that URL:

	https://www.quinapalus.com/hd44780udg.html

The createChar() method is defined in the library module file "i2c_lcd_v3.py" as follows:

    # New method (member function) to create 8 custom characters    
    def createChar(self, location, custChars):
        location = location & 0x07
        self.setcmd(0x40 | (location << 3))  
        for i in range(8):
            self.setdat(custChars[i])

So, later in the test program, I can uses these custom characters as follows:

    degC = 22.0
    myLCD2.puts(str(degC) + str(chr(0x00)) + "C ", 9, 1)    # "chr(0x00)" specifies the degrees symbol


The test program I wrote for it is called "testCustomChars_3.py". 

This test program has more examples. Also, my test programs test custom characters on both 
the 1602_LCD and the 2004_LCD displays. It worked on the 2004_LCD with no code changes other 
than the fact that the 2004_LCD comes with 4 more characters per line that you can easily use.

My new library module filename is "i2c_lcd_v3.py". This file needs to be copied to the ESP8266's 
file system in flash memory. I use Thonny MicroPython IDE which has a "Device" menu  with several
"Upload..." commands designed for this purpose. If you are not using Thonny, maybe you can use
"ampy.py" or some similar utility.



