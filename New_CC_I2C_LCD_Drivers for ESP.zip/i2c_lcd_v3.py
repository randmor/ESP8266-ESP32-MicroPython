'''
    i2c_lcd.py
    
    This MicroPython for ESP8266 device driver supports
    both I2C_1602_LCDs and I2C_2004_LCDs. This version
    adds the capability to create and display up to eight
    different custom characters via the new createChar() method.
    
    Mucker: Wm Moore    (2019.6)
    
    Author: shaoziyang  (2018.2)
    http://www.micropython.org.cn 

'''

import time
from machine import I2C    # Pin, 

class LCD():
    def __init__(self, i2c, addrs, mod):
        self.i2c = i2c
        self.i2cAddrs = addrs
        self.model = mod
        self.buf = bytearray(1)
        self.BK = 0x08
        self.RS = 0x00
        self.E = 0x04
        self.setcmd(0x33)
        time.sleep_ms(5)
        self.send(0x30)
        time.sleep_ms(5)
        self.send(0x20)
        time.sleep_ms(5)
        self.setcmd(0x28)  
        self.setcmd(0x0C)
        self.setcmd(0x06)
        self.setcmd(0x01)        
        self.version='1.0'

    def setReg(self, dat):
        self.buf[0] = dat
        self.i2c.writeto(self.i2cAddrs, self.buf)
        time.sleep_ms(1)

    def send(self, dat):
        d=dat&0xF0
        d|=self.BK
        d|=self.RS
        self.setReg(d)
        self.setReg(d|0x04)
        self.setReg(d)

    def setcmd(self, cmd):
        self.RS=0
        self.send(cmd)
        self.send(cmd<<4)

    def setdat(self, dat):
        self.RS=1
        self.send(dat)
        self.send(dat<<4)

    def clear(self):
        self.setcmd(1)

    def backlight(self, on):
        if on:
            self.BK=0x08
        else:
            self.BK=0
        self.setcmd(0)

    def on(self):
        self.setcmd(0x0C)

    def off(self):
        self.setcmd(0x08)

    def shl(self):
        self.setcmd(0x18)

    def shr(self):
        self.setcmd(0x1C)

    def char(self, ch, x=-1, y=0):
        a=0xC0
        if x>=0:
            
            # For 1602_LCD:
            if self.model == 1602:
                if y==0 or y==2:
                    a=0x80            # Cmd for displaying text on line 0
                elif y==1 or y==3:
                    a=0xC0            # Cmd for displaying text on line 1        
 
            # For 2004_LCD:
            elif self.model == 2004:        
                if y==0:
                    a=0x80            # Cmd for displaying text on line 0
                elif y==1:
                    a=0xC0            # Cmd for displaying text on line 1
                elif y == 2:
                    a=0x94            # Cmd for displaying text on line 2
                else:
                    a=0xD4            # Cmd for displaying text on line 3  

            else:
                print("Model error in 'char()' method.")
                    
            a+=x
            self.setcmd(a)
        self.setdat(ch)

    def puts(self, string, x=0, y=0):
        if len(string)>0:
            self.char(ord(string[0]),x,y)
            for i in range(1, len(string)):
                self.char(ord(string[i]))

    def get_model(self):
        return self.model

    # New method (member function) to create 8 custom characters    
    def createChar(self, location, custChars):
        location = location & 0x07
        self.setcmd(0x40 | (location << 3))  
        for i in range(8):
            self.setdat(custChars[i])
            
# EOF
